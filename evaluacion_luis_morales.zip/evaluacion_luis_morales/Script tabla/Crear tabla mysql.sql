CREATE SCHEMA `evaluacion` ;
CREATE TABLE `evaluacion`.`vb_evaluacion` (
  `id` INT NOT NULL,
  `nombre` VARCHAR(45) NULL,
  `monto` DECIMAL NULL,
  PRIMARY KEY (`id`));

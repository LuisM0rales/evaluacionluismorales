﻿namespace Evaluacion
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView = new DataGridView();
            CrearExcel = new Button();
            CrearWord = new Button();
            ExcelAMySQL = new Button();
            TXTAMySQL = new Button();
            CSVAMySQL = new Button();
            ExcelDesdeGrid = new Button();
            WordDesdeGrid = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView).BeginInit();
            SuspendLayout();
            // 
            // dataGridView
            // 
            dataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView.Location = new Point(52, 155);
            dataGridView.Name = "dataGridView";
            dataGridView.RowHeadersWidth = 51;
            dataGridView.RowTemplate.Height = 29;
            dataGridView.Size = new Size(652, 258);
            dataGridView.TabIndex = 0;
            // 
            // CrearExcel
            // 
            CrearExcel.Location = new Point(52, 53);
            CrearExcel.Name = "CrearExcel";
            CrearExcel.Size = new Size(131, 29);
            CrearExcel.TabIndex = 1;
            CrearExcel.Text = "Crear Excel";
            CrearExcel.UseVisualStyleBackColor = true;
            CrearExcel.Click += CrearExcel_Click;
            // 
            // CrearWord
            // 
            CrearWord.Location = new Point(194, 53);
            CrearWord.Name = "CrearWord";
            CrearWord.Size = new Size(130, 29);
            CrearWord.TabIndex = 2;
            CrearWord.Text = "Crear Word";
            CrearWord.UseVisualStyleBackColor = true;
            CrearWord.Click += CrearWord_Click;
            // 
            // ExcelAMySQL
            // 
            ExcelAMySQL.Location = new Point(330, 53);
            ExcelAMySQL.Name = "ExcelAMySQL";
            ExcelAMySQL.Size = new Size(124, 29);
            ExcelAMySQL.TabIndex = 3;
            ExcelAMySQL.Text = "Excel a MySQL";
            ExcelAMySQL.UseVisualStyleBackColor = true;
            ExcelAMySQL.Click += ExcelAMySQL_Click;
            // 
            // TXTAMySQL
            // 
            TXTAMySQL.Location = new Point(460, 53);
            TXTAMySQL.Name = "TXTAMySQL";
            TXTAMySQL.Size = new Size(121, 29);
            TXTAMySQL.TabIndex = 4;
            TXTAMySQL.Text = "TXT a MySQL";
            TXTAMySQL.UseVisualStyleBackColor = true;
            TXTAMySQL.Click += TXTAMySQL_Click;
            // 
            // CSVAMySQL
            // 
            CSVAMySQL.Location = new Point(587, 53);
            CSVAMySQL.Name = "CSVAMySQL";
            CSVAMySQL.Size = new Size(117, 29);
            CSVAMySQL.TabIndex = 5;
            CSVAMySQL.Text = "CSV a MySQL";
            CSVAMySQL.UseVisualStyleBackColor = true;
            CSVAMySQL.Click += CSVAMySQL_Click;
            // 
            // ExcelDesdeGrid
            // 
            ExcelDesdeGrid.Location = new Point(52, 88);
            ExcelDesdeGrid.Name = "ExcelDesdeGrid";
            ExcelDesdeGrid.Size = new Size(131, 29);
            ExcelDesdeGrid.TabIndex = 6;
            ExcelDesdeGrid.Text = "Excel desde grid";
            ExcelDesdeGrid.UseVisualStyleBackColor = true;
            ExcelDesdeGrid.Click += ExcelDesdeGrid_Click;
            // 
            // WordDesdeGrid
            // 
            WordDesdeGrid.Location = new Point(194, 88);
            WordDesdeGrid.Name = "WordDesdeGrid";
            WordDesdeGrid.Size = new Size(130, 29);
            WordDesdeGrid.TabIndex = 7;
            WordDesdeGrid.Text = "Word desde grid";
            WordDesdeGrid.UseVisualStyleBackColor = true;
            WordDesdeGrid.Click += WordDesdeGrid_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(WordDesdeGrid);
            Controls.Add(ExcelDesdeGrid);
            Controls.Add(CSVAMySQL);
            Controls.Add(TXTAMySQL);
            Controls.Add(ExcelAMySQL);
            Controls.Add(CrearWord);
            Controls.Add(CrearExcel);
            Controls.Add(dataGridView);
            Name = "Form1";
            Text = "Evaluacion";
            ((System.ComponentModel.ISupportInitialize)dataGridView).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridView;
        private Button CrearExcel;
        private Button CrearWord;
        private Button ExcelAMySQL;
        private Button TXTAMySQL;
        private Button CSVAMySQL;
        private Button ExcelDesdeGrid;
        private Button WordDesdeGrid;
    }
}
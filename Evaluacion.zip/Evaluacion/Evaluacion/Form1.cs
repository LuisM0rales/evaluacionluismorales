using Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.Word;
using System.Runtime.InteropServices;
using MySql.Data.MySqlClient;
using System.Windows.Forms;
using CsvHelper.Configuration;
using CsvHelper;
using System.Globalization;
using System;
using System.IO;

namespace Evaluacion
{
    public partial class Form1 : Form
    {
        public string nombre = "luis_morales";
        private string connectionString = "Server=localhost,3306;Database=evaluacion;User=root;Password=Wolf_stark1;";
        public Form1()
        {
            InitializeComponent();

            // Configura el DataGridView y las columnas
            dataGridView.AutoGenerateColumns = false;
            dataGridView.Columns.Add("Id", "Id");
            dataGridView.Columns.Add("Nombre", "Nombre");
            dataGridView.Columns.Add("Profesion", "Profesi�n");
            dataGridView.Columns.Add("Salario", "Salario");

            // Genera datos ficticios y agrega filas al DataGridView
            Random random = new Random();
            for (int i = 1; i <= 15; i++)
            {
                string nombre = "Empleado " + i;
                string profesion = "Profesi�n " + random.Next(1, 6); // Profesi�n aleatoria del 1 al 5
                decimal salario = (decimal)(random.Next(2000, 5000)) / 100; // Salario aleatorio entre 20.00 y 50.00
                string id = i.ToString("D5");
                dataGridView.Rows.Add(id, nombre, profesion, salario);
            }
        }

        private void CrearExcel_Click(object sender, EventArgs e)
        {
            // Obtener el nombre del archivo de salida
            string nombreArchivo = $"{nombre}_excel.xlsx";
            string rutaArchivo = Path.Combine(@"C:\evaluacion_exports", nombreArchivo);

            try
            {
                // Crear una instancia de Excel
                var excelApp = new Microsoft.Office.Interop.Excel.Application();
                var workbooks = excelApp.Workbooks;
                var workbook = workbooks.Add(XlWBATemplate.xlWBATWorksheet);

                // Agregar datos a la hoja de trabajo
                var worksheet = (Worksheet)workbook.Worksheets[1];

                int filas = 5;
                int columnas = 5;

                for (int fila = 1; fila <= filas; fila++)
                {
                    for (int columna = 1; columna <= columnas; columna++)
                    {
                        worksheet.Cells[fila, columna] = (fila - 1) * (columna - 1);
                    }
                }

                // Guardar el archivo Excel
                workbook.SaveAs(rutaArchivo);

                // Cerrar y liberar recursos
                workbook.Close(false);
                Marshal.ReleaseComObject(workbook);
                excelApp.Quit();
                Marshal.ReleaseComObject(excelApp);

                MessageBox.Show("Se ha generado y guardado el archivo: " + nombreArchivo);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al crear el archivo Excel: {ex.Message}");
            }
        }

        private void CrearWord_Click(object sender, EventArgs e)
        {

            // Construir el nombre del archivo Word
            string nombreArchivo = $"{nombre}_word.docx";
            string rutaArchivo = Path.Combine(@"C:\evaluacion_exports", nombreArchivo);

            try
            {
                // Crear una instancia de Word
                var wordApp = new Microsoft.Office.Interop.Word.Application();
                var doc = wordApp.Documents.Add();

                // Agregar contenido al documento
                doc.Content.Text = $"Evaluaci�n .net 2023\r\nVentas\r\nResumen de ventas:\r\n";

                // Crear una tabla
                Table tabla = doc.Tables.Add(doc.Content, 4, 5); // 4 filas, 5 columnas

                tabla.Borders.Enable = 1;
                tabla.Borders.InsideLineStyle = WdLineStyle.wdLineStyleSingle;
                tabla.Borders.OutsideLineStyle = WdLineStyle.wdLineStyleSingle;

                // Agregar encabezados de columna
                tabla.Cell(1, 1).Range.Text = "Fecha y Hora";
                tabla.Cell(1, 2).Range.Text = "Vendedor";
                tabla.Cell(1, 3).Range.Text = "Mes 1";
                tabla.Cell(1, 4).Range.Text = "Mes 2";
                tabla.Cell(1, 5).Range.Text = "Mes 3";

                // Agregar datos de ejemplo (reemplaza con tus datos reales)
                tabla.Cell(2, 1).Range.Text = DateTime.Now.ToString(); // Fecha y hora
                tabla.Cell(2, 2).Range.Text = "Vendedor 1";
                tabla.Cell(2, 3).Range.Text = "1000";
                tabla.Cell(2, 4).Range.Text = "1500";
                tabla.Cell(2, 5).Range.Text = "2000";

                tabla.Cell(3, 1).Range.Text = DateTime.Now.ToString();
                tabla.Cell(3, 2).Range.Text = "Vendedor 2";
                tabla.Cell(3, 3).Range.Text = "800";
                tabla.Cell(3, 4).Range.Text = "1200";
                tabla.Cell(3, 5).Range.Text = "1800";

                // Calcular la suma de los valores de cada mes
                int sumaMes1 = 1000 + 800;
                int sumaMes2 = 1500 + 1200;
                int sumaMes3 = 2000 + 1800;

                tabla.Cell(4, 2).Range.Text = "Total";
                tabla.Cell(4, 3).Range.Text = sumaMes1.ToString();
                tabla.Cell(4, 4).Range.Text = sumaMes2.ToString();
                tabla.Cell(4, 5).Range.Text = sumaMes3.ToString();

                // Guardar el documento de Word
                doc.SaveAs2(rutaArchivo);

                // Cerrar y liberar recursos
                doc.Close();
                Marshal.ReleaseComObject(doc);
                wordApp.Quit();
                Marshal.ReleaseComObject(wordApp);

                MessageBox.Show($"Se ha generado y guardado el archivo: {nombreArchivo}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al crear el archivo de Word: {ex.Message}");
            }
        }

        private void ExcelDesdeGrid_Click(object sender, EventArgs e)
        {
            // Construir el nombre del archivo Excel
            string nombreArchivo = $"{nombre}_excel_datagrid.xlsx";
            string rutaArchivo = Path.Combine(@"C:\evaluacion_exports", nombreArchivo);

            try
            {
                // Crear una instancia de Excel
                var excelApp = new Microsoft.Office.Interop.Excel.Application();
                var workbooks = excelApp.Workbooks;
                var workbook = workbooks.Add(XlWBATemplate.xlWBATWorksheet);

                // Obtener la hoja de trabajo
                var worksheet = (Worksheet)workbook.Worksheets[1];

                // Obtener datos del DataGridView y escribirlos en la hoja de trabajo
                int rowIndex = 1;
                foreach (DataGridViewRow row in dataGridView.Rows)
                {
                    int columnIndex = 1;
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        worksheet.Cells[rowIndex, columnIndex] = cell.Value;
                        columnIndex++;
                    }
                    rowIndex++;
                }

                // Guardar el archivo Excel
                workbook.SaveAs(rutaArchivo);

                // Cerrar y liberar recursos
                workbook.Close(false);
                Marshal.ReleaseComObject(workbook);
                excelApp.Quit();
                Marshal.ReleaseComObject(excelApp);

                MessageBox.Show($"Se ha generado y guardado el archivo: {nombreArchivo}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al crear el archivo de Excel: {ex.Message}");
            }
        }

        private void WordDesdeGrid_Click(object sender, EventArgs e)
        {
            // Construir el nombre del archivo Word
            string nombreArchivo = $"{nombre}_word_datagrid.docx";
            string rutaArchivo = Path.Combine(@"C:\evaluacion_exports", nombreArchivo);

            try
            {
                // Crear una instancia de Word
                var wordApp = new Microsoft.Office.Interop.Word.Application();
                var doc = wordApp.Documents.Add();

                // Agregar el contenido al documento
                doc.Content.Text = "Reporte generado a partir de datagrid\r\nDetalle de personas:\r\n";

                // Crear una tabla para el contenido del DataGridView
                var table = doc.Tables.Add(doc.Bookmarks.get_Item("\\endofdoc").Range, dataGridView.Rows.Count + 1, dataGridView.Columns.Count);
                table.Borders.InsideLineStyle = WdLineStyle.wdLineStyleSingle; // Estilo de l�nea interna
                table.Borders.OutsideLineStyle = WdLineStyle.wdLineStyleSingle; // Estilo de l�nea externa

                // Agregar encabezados de columna
                for (int i = 0; i < dataGridView.Columns.Count; i++)
                {
                    table.Cell(1, i + 1).Range.Text = dataGridView.Columns[i].HeaderText;
                }

                // Agregar datos del DataGridView
                for (int row = 0; row < dataGridView.Rows.Count; row++)
                {
                    for (int col = 0; col < dataGridView.Columns.Count; col++)
                    {
                        table.Cell(row + 2, col + 1).Range.Text = (dataGridView.Rows[row].Cells[col].Value==null) ? " " : dataGridView.Rows[row].Cells[col].Value.ToString();
                    }
                }

                // Guardar el archivo Word
                doc.SaveAs2(rutaArchivo);

                // Cerrar y liberar recursos
                doc.Close();
                Marshal.ReleaseComObject(doc);
                wordApp.Quit();
                Marshal.ReleaseComObject(wordApp);

                MessageBox.Show($"Se ha generado y guardado el archivo: {nombreArchivo}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al crear el archivo de Word: {ex.Message}");
            }
        }

        private void ExcelAMySQL_Click(object sender, EventArgs e)
        {
            try
            {
                // Ruta del archivo Excel
                string rutaArchivoExcel = "C:\\evaluacion_imports\\import1.xlsx";

                // Establecer una cadena de conexi�n MySQL
                
                MySqlConnection conexion = new MySqlConnection(connectionString);

                // Abrir la conexi�n MySQL
                conexion.Open();

                // Crear un objeto Excel y abrir el archivo
                var excelApp = new Microsoft.Office.Interop.Excel.Application();
                var workbook = excelApp.Workbooks.Open(rutaArchivoExcel);
                var worksheet = (Worksheet)workbook.Sheets[1];

                // Obtener el rango de celdas utilizadas en la hoja de trabajo
                var range = worksheet.UsedRange;
                int rowCount = range.Rows.Count;
                int columnCount = range.Columns.Count;

                // Iterar a trav�s de las filas y columnas y almacenar los datos en MySQL
                for (int row = 2; row <= rowCount; row++) // Suponiendo que la primera fila contiene encabezados
                {
                    MySqlCommand cmd = new MySqlCommand("INSERT INTO vb_evaluacion (Id, Nombre, Monto) VALUES (@Id, @Nombre, @Monto)", conexion);

                    for (int col = 1; col <= columnCount; col++)
                    {
                        string valorCelda = ((Microsoft.Office.Interop.Excel.Range)range.Cells[row, col]).Text;
                        cmd.Parameters.AddWithValue($"@{range.Cells[1, col].Text}", valorCelda);
                    }

                    cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                }

                // Cerrar y liberar recursos
                workbook.Close(false);
                Marshal.ReleaseComObject(workbook);
                excelApp.Quit();
                Marshal.ReleaseComObject(excelApp);

                conexion.Close();

                MessageBox.Show($"El archivo: import1.xlsx ha sido importado a la base de datos.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al importar el archivo a la base de datos: {ex.Message}");
            }
        }

        private void TXTAMySQL_Click(object sender, EventArgs e)
        {
            // Ruta del archivo TXT
            string rutaArchivoTXT = "C:\\evaluacion_imports\\import2.txt";

            try
            {
                // Establecer una cadena de conexi�n MySQL
                MySqlConnection conexion = new MySqlConnection(connectionString);

                // Abrir la conexi�n MySQL
                conexion.Open();

                // Leer el contenido del archivo TXT
                string[] lineas = File.ReadAllLines(rutaArchivoTXT);

                // Crear una instrucci�n SQL para insertar los datos en la tabla
                MySqlCommand cmd = new MySqlCommand("INSERT INTO vb_evaluacion (Id, Nombre, Monto) VALUES (@Id, @Nombre, @Monto)", conexion);

                foreach (string linea in lineas)
                {
                    string[] campos = linea.Split(' '); // Supongo que los campos est�n separados por tabulaciones ('\t')

                    if (campos.Length >= 3)
                    {
                        cmd.Parameters.AddWithValue("@Id", campos[0]);
                        cmd.Parameters.AddWithValue("@Nombre", campos[1]);
                        cmd.Parameters.AddWithValue("@Monto", campos[2]);

                        cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }

                // Cerrar y liberar recursos
                conexion.Close();

                MessageBox.Show($"El archivo: import2.txt ha sido importado a la base de datos.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al importar el archivo a la base de datos: {ex.Message}");
            }
        }

        private void CSVAMySQL_Click(object sender, EventArgs e)
        {
            // Ruta del archivo CSV
            string rutaArchivoCSV = "C:\\evaluacion_imports\\import3.csv";

            try
            {
                // Establecer una cadena de conexi�n MySQL
                MySqlConnection conexion = new MySqlConnection(connectionString);

                // Abrir la conexi�n MySQL
                conexion.Open();

                // Configurar el lector CSV
                var config = new CsvConfiguration(CultureInfo.InvariantCulture)
                {
                    Delimiter = ",", // Establece el delimitador utilizado en tu archivo CSV
                    HasHeaderRecord = true, // Indica que la primera fila es el encabezado
                };

                // Leer el contenido del archivo CSV
                using (var reader = new StreamReader(rutaArchivoCSV))
                using (var csv = new CsvReader(reader, config))
                {
                    var registros = csv.GetRecords<RegistroCSV>(); // Cambia RegistroCSV al nombre de tu clase que representar� una fila en el CSV

                    // Crear una instrucci�n SQL para insertar los datos en la tabla
                    MySqlCommand cmd = new MySqlCommand("INSERT INTO vb_evaluacion (Id, Nombre, Monto) VALUES (@Id, @Nombre, @Monto)", conexion);

                    foreach (var registro in registros)
                    {
                        cmd.Parameters.AddWithValue("@Id", registro.id);
                        cmd.Parameters.AddWithValue("@Nombre", registro.nombre);
                        cmd.Parameters.AddWithValue("@Monto", registro.monto);

                        cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }

                // Cerrar y liberar recursos
                conexion.Close();

                MessageBox.Show($"El archivo: import3.csv ha sido importado a la base de datos.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al importar el archivo a la base de datos: {ex.Message}");
            }
        }
    }
    // Clase para representar una fila en el archivo CSV
    public class RegistroCSV
    {
        public string id { get; set; }
        public string nombre { get; set; }
        public string monto { get; set; }
    }
}